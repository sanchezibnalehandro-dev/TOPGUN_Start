(() => {
  "use strict";

  const STORAGE_KEY = "topgun-start-progress";
  const SCHEMA_VERSION = 2;
  const modules = Array.isArray(window.TOPGUN_MODULES) ? window.TOPGUN_MODULES : [];
  const questionSets = window.TOPGUN_QUESTIONS && typeof window.TOPGUN_QUESTIONS === "object" ? window.TOPGUN_QUESTIONS : {};
  const practiceConfig = window.TOPGUN_PRACTICE || {};
  const sourceConfig = window.TOPGUN_SOURCES || {};
  const app = document.getElementById("app");
  let storageReadonly = false;
  let systemNotice = "";

  const create = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };

  const append = (parent, ...children) => {
    children.flat().filter(Boolean).forEach((child) => parent.append(child));
    return parent;
  };

  const button = (label, className, onClick) => {
    const node = create("button", className, label);
    node.type = "button";
    node.addEventListener("click", onClick);
    return node;
  };

  const todayIso = () => new Date().toISOString();
  const fullModules = () => modules.filter((module) => module.kind === "full");
  const questionsFor = (module) => questionSets[module?.test?.questionSetId] || [];
  const sourceById = (id) => sourceConfig.items?.find((item) => item.id === id);
  const levelById = (id) => practiceConfig.levels?.find((level) => level.id === id) || practiceConfig.levels?.[0];
  const skillById = (id) => practiceConfig.module02Skills?.find((skill) => skill.id === id);

  const blankTheory = () => ({ answers: {}, attempts: 0, bestScore: 0, lastScore: null, incorrectTopics: [] });
  const blankReview = () => ({ status: "pending", comment: "", confirmedAt: null });
  const defaultProgress = (migration = null) => ({
    progressSchemaVersion: SCHEMA_VERSION,
    traineeName: "Стажёр",
    currentModuleId: "01",
    modules: Object.fromEntries(fullModules().map((module) => [module.id, {
      materialsCompleted: Object.fromEntries((module.sections || []).map((section) => [section.id, false])),
      theory: blankTheory(),
      mentorReview: blankReview()
    }])),
    skills: Object.fromEntries((practiceConfig.module02Skills || []).map((skill) => [skill.id, {
      level: "not_started",
      mentorReview: blankReview()
    }])),
    manualUnlocks: {},
    migration
  });

  const cleanString = (value, fallback = "") => typeof value === "string" ? value : fallback;
  const normalizeReview = (candidate) => ({
    status: ["pending", "accepted", "repeat"].includes(candidate?.status) ? candidate.status : "pending",
    comment: cleanString(candidate?.comment),
    confirmedAt: typeof candidate?.confirmedAt === "string" ? candidate.confirmedAt : null
  });

  const normalizeV2 = (candidate) => {
    const base = defaultProgress(candidate?.migration && typeof candidate.migration === "object" ? candidate.migration : null);
    base.traineeName = cleanString(candidate?.traineeName).trim() || base.traineeName;
    base.currentModuleId = modules.some((module) => module.id === candidate?.currentModuleId) ? candidate.currentModuleId : base.currentModuleId;
    fullModules().forEach((module) => {
      const old = candidate?.modules?.[module.id] || {};
      (module.sections || []).forEach((section) => {
        base.modules[module.id].materialsCompleted[section.id] = Boolean(old.materialsCompleted?.[section.id]);
      });
      const theory = old.theory || {};
      base.modules[module.id].theory = {
        answers: theory.answers && typeof theory.answers === "object" ? theory.answers : {},
        attempts: Number.isInteger(theory.attempts) ? Math.max(0, theory.attempts) : 0,
        bestScore: Number.isInteger(theory.bestScore) ? Math.max(0, theory.bestScore) : 0,
        lastScore: Number.isInteger(theory.lastScore) ? Math.max(0, theory.lastScore) : null,
        incorrectTopics: Array.isArray(theory.incorrectTopics) ? theory.incorrectTopics.filter((item) => typeof item === "string") : []
      };
      base.modules[module.id].mentorReview = normalizeReview(old.mentorReview);
    });
    (practiceConfig.module02Skills || []).forEach((skill) => {
      const old = candidate?.skills?.[skill.id] || {};
      base.skills[skill.id].level = practiceConfig.levels.some((level) => level.id === old.level) ? old.level : "not_started";
      base.skills[skill.id].mentorReview = normalizeReview(old.mentorReview);
    });
    if (candidate?.manualUnlocks && typeof candidate.manualUnlocks === "object") {
      Object.entries(candidate.manualUnlocks).forEach(([moduleId, unlock]) => {
        if (modules.some((module) => module.id === moduleId) && unlock && typeof unlock === "object") {
          base.manualUnlocks[moduleId] = { openedAt: cleanString(unlock.openedAt), comment: cleanString(unlock.comment) };
        }
      });
    }
    return base;
  };

  const migrateV1 = (candidate, raw) => {
    const migrated = defaultProgress({
      fromSchemaVersion: Number(candidate?.progressSchemaVersion) || 1,
      migratedAt: todayIso(),
      v1Backup: raw,
      noticePending: true
    });
    migrated.traineeName = cleanString(candidate?.traineeName || candidate?.name).trim() || migrated.traineeName;
    return migrated;
  };

  const loadProgress = () => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return defaultProgress();
      const parsed = JSON.parse(raw);
      if (Number(parsed.progressSchemaVersion) > SCHEMA_VERSION) {
        storageReadonly = true;
        systemNotice = "Этот прогресс создан более новой версией приложения. Данные открыты только для чтения и не будут перезаписаны.";
        return defaultProgress();
      }
      if (Number(parsed.progressSchemaVersion) === SCHEMA_VERSION) return normalizeV2(parsed);
      const migrated = migrateV1(parsed, raw);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(migrated));
      return migrated;
    } catch {
      storageReadonly = true;
      systemNotice = "Не удалось прочитать локальный прогресс. Открыта чистая версия только для чтения; сохранённые данные не изменены.";
      return defaultProgress();
    }
  };

  let progress = loadProgress();
  const moduleState = (id) => progress.modules[id];
  const materialsDone = (module) => module.kind === "full" && (module.sections || []).every((section) => moduleState(module.id)?.materialsCompleted?.[section.id]);
  const theoryPassed = (module) => module.kind === "full" && moduleState(module.id)?.theory.bestScore >= module.test.passScore;
  const reviewAccepted = (module) => moduleState(module.id)?.mentorReview.status === "accepted";
  const skillRank = (skillId) => levelById(progress.skills[skillId]?.level)?.rank || 0;
  const allModule02SkillsWithMentor = () => (practiceConfig.module02Skills || []).every((skill) => skillRank(skill.id) >= 2);

  const moduleComplete = (module) => {
    if (module.id === "01") return materialsDone(module) && theoryPassed(module) && reviewAccepted(module);
    if (module.id === "02") return materialsDone(module) && theoryPassed(module) && allModule02SkillsWithMentor() && reviewAccepted(module);
    return false;
  };

  const moduleUnlocked = (module) => {
    if (module.id === "01") return true;
    if (progress.manualUnlocks[module.id]) return true;
    const index = modules.findIndex((item) => item.id === module.id);
    return index > 0 && moduleComplete(modules[index - 1]);
  };

  const moduleStatus = (module) => {
    if (moduleComplete(module)) return { tone: "done", label: "завершён", locked: false };
    if (progress.manualUnlocks[module.id]) return { tone: "mentor", label: "открыт наставником", locked: false };
    if (!moduleUnlocked(module)) return { tone: "locked", label: "закрыт", locked: true };
    if (progress.currentModuleId === module.id) return { tone: "current", label: "сейчас", locked: false };
    return { tone: module.kind === "unfinished" ? "unfinished" : "available", label: module.kind === "unfinished" ? "контент готовится" : "доступен", locked: false };
  };

  const routeProgress = () => Math.round((modules.filter(moduleComplete).length / modules.length) * 100);
  const save = () => {
    if (storageReadonly) return false;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    return true;
  };

  const sectionCard = (title, meta, id) => {
    const card = create("section", "surface reveal");
    if (id) card.id = id;
    const header = create("div", "section-heading");
    append(header, create("h2", "section-title", title));
    if (meta) append(header, create("span", "section-meta", meta));
    append(card, header);
    return card;
  };

  const sourceLine = (sourceIds = []) => {
    const names = sourceIds.map(sourceById).filter(Boolean).map((source) => source.title);
    if (!names.length) return null;
    return create("p", "source-line", `Источник: ${names.join(" · ")}`);
  };

  const renderHeader = () => {
    const header = create("header", "topbar");
    const brand = create("div", "brand-block");
    append(brand, create("p", "eyebrow", "TOPGUN · внутренняя стажировка"), create("h1", "brand-title", "Старт"), create("p", "brand-copy", "Реальный маршрут подготовки барбера · версия 0.2"));
    const actions = create("div", "top-actions");
    const rename = button("Изменить имя", "button button-quiet", () => {
      const value = window.prompt("Имя стажёра:", progress.traineeName);
      if (value?.trim()) {
        progress.traineeName = value.trim();
        save();
        render();
      }
    });
    rename.disabled = storageReadonly;
    append(actions, rename, button("Сбросить прогресс", "button button-outline", resetProgress));
    append(header, brand, actions);
    return header;
  };

  const renderNotices = (frame) => {
    if (systemNotice) append(frame, create("div", "schema-notice", systemNotice));
    if (progress.migration?.noticePending) {
      const notice = create("div", "migration-notice");
      const copy = create("div", "");
      append(copy, create("strong", "", "Прогресс обновлён для v0.2"), create("p", "", "Имя сохранено. Демонстрационные зачёты v0.1 не перенесены в реальный маршрут; исходные данные сохранены локально в резервной записи миграции."));
      const dismiss = button("Понятно", "button button-secondary", () => {
        progress.migration.noticePending = false;
        save();
        render();
      });
      dismiss.disabled = storageReadonly;
      append(notice, copy, dismiss);
      append(frame, notice);
    }
  };

  const renderSummary = () => {
    const selected = modules.find((module) => module.id === progress.currentModuleId) || modules[0];
    const summary = create("section", "journey-hero");
    const copy = create("div", "hero-copy");
    append(copy, create("span", "version-marker", "v0.2 · реальные материалы"), create("p", "hero-kicker", `${progress.traineeName} · маршрут стажировки`), create("h2", "hero-title", selected.title));
    append(copy, create("p", "hero-text", moduleComplete(selected) ? "Занятие завершено. Практические навыки продолжают жить в отдельной карте освоения." : selected.summary));
    const dial = create("div", "progress-dial");
    const percent = routeProgress();
    dial.style.setProperty("--progress", `${percent * 3.6}deg`);
    append(dial, create("strong", "progress-value", `${percent}%`), create("span", "progress-caption", "маршрут"));
    append(summary, copy, dial);
    return summary;
  };

  const renderRoute = () => {
    const aside = create("aside", "route-panel");
    append(aside, create("p", "eyebrow", "Маршрут стажировки"), create("h2", "route-title", "Шесть занятий"), create("p", "route-caption", "Последовательно по умолчанию · порядок практики может открыть наставник."));
    const list = create("nav", "route-list");
    list.setAttribute("aria-label", "Маршрут стажировки");
    modules.forEach((module) => {
      const status = moduleStatus(module);
      const item = create("button", `route-item route-${status.tone}`);
      item.type = "button";
      item.disabled = status.locked;
      item.setAttribute("aria-current", progress.currentModuleId === module.id ? "step" : "false");
      const body = create("span", "route-content");
      append(body, create("span", "route-name", module.title), create("span", "route-summary", module.summary));
      append(item, create("span", "route-number", module.id), body, create("span", `route-status status-${status.tone}`, status.label));
      if (!status.locked) item.addEventListener("click", () => {
        progress.currentModuleId = module.id;
        save();
        render();
      });
      append(list, item);
    });
    append(aside, list);
    return aside;
  };

  const renderLead = (module) => {
    const lead = create("section", "module-lead reveal");
    append(lead, create("p", "eyebrow", `${module.id} · ${module.kind === "full" ? "полное занятие" : "структура занятия"}`), create("h1", "module-title", module.title), create("p", "module-purpose", module.purpose || module.summary));
    if (module.kind === "full") {
      const stages = create("ol", "stage-list");
      const stageStates = [materialsDone(module), theoryPassed(module), module.id === "02" ? allModule02SkillsWithMentor() : reviewAccepted(module), reviewAccepted(module)];
      const labels = module.id === "02" ? ["Материал", "Тест", "Практика", "Наставник"] : ["Материал", "Тест", "Разбор", "Наставник"];
      labels.forEach((label, index) => append(stages, create("li", stageStates[index] ? "stage-complete" : "stage-pending", label)));
      append(lead, stages);
    }
    return lead;
  };

  const renderOutcomes = (module) => {
    const card = sectionCard("После занятия стажёр должен уметь", "наблюдаемые действия");
    const grid = create("div", "outcomes-grid");
    module.outcomes.forEach((outcome, index) => {
      const item = create("div", "outcome-item");
      append(item, create("span", "outcome-index", String(index + 1).padStart(2, "0")), create("p", "", outcome));
      append(grid, item);
    });
    append(card, grid);
    return card;
  };

  const renderSectionNav = (module) => {
    const nav = create("nav", "lesson-nav");
    nav.setAttribute("aria-label", "Разделы занятия");
    append(nav, create("span", "lesson-nav-label", "Быстрый переход"));
    module.sections.forEach((section, index) => {
      const link = create("a", moduleState(module.id).materialsCompleted[section.id] ? "lesson-link lesson-link-done" : "lesson-link", `${String(index + 1).padStart(2, "0")} ${section.title}`);
      link.href = `#lesson-${module.id}-${section.id}`;
      append(nav, link);
    });
    return nav;
  };

  const renderLearningSections = (module) => {
    const container = create("div", "learning-sections");
    module.sections.forEach((section, index) => {
      const card = sectionCard(section.title, `${index + 1} / ${module.sections.length}`, `lesson-${module.id}-${section.id}`);
      if (section.callout) append(card, create("aside", "editorial-note", section.callout));
      (section.paragraphs || []).forEach((paragraph) => append(card, create("p", "lesson-copy", paragraph)));
      if (section.bullets?.length) {
        const list = create("ul", "content-list");
        section.bullets.forEach((item) => append(list, create("li", "", item)));
        append(card, list);
      }
      append(card, sourceLine(section.sourceIds));
      const completion = create("label", "material-complete");
      const input = create("input", "");
      input.type = "checkbox";
      input.checked = Boolean(moduleState(module.id).materialsCompleted[section.id]);
      input.disabled = storageReadonly;
      input.addEventListener("change", () => {
        moduleState(module.id).materialsCompleted[section.id] = input.checked;
        save();
        render();
        document.getElementById(`lesson-${module.id}-${section.id}`)?.scrollIntoView({ block: "start" });
      });
      append(completion, input, create("span", "material-box"), create("span", "", "Материал изучен"));
      append(card, completion);
      append(container, card);
    });
    return container;
  };

  const renderTestResult = (module) => {
    const theory = moduleState(module.id).theory;
    if (theory.lastScore === null) return null;
    const passed = theory.lastScore >= module.test.passScore;
    const panel = create("div", `test-result ${passed ? "result-good" : "result-bad"}`);
    append(panel, create("strong", "", passed ? `Тест пройден · ${theory.lastScore}/${questionsFor(module).length}` : `${theory.lastScore}/${questionsFor(module).length} · материал стоит повторить`));
    if (passed) append(panel, create("p", "", module.id === "02" ? "Теория пройдена. Практические навыки и итог занятия подтверждает наставник." : "Теоретическая часть завершена. Следующий шаг — разбор с наставником."));
    else append(panel, create("p", "", `Повторите темы: ${theory.incorrectTopics.join(", ") || "все разделы"}. Попыток: ${theory.attempts}.`));
    return panel;
  };

  const evaluateTest = (module) => {
    const theory = moduleState(module.id).theory;
    let score = 0;
    const incorrect = new Set();
    questionsFor(module).forEach((question) => {
      if (Number(theory.answers[question.id]) === question.correctIndex) score += 1;
      else incorrect.add(question.topic);
    });
    theory.attempts += 1;
    theory.lastScore = score;
    theory.bestScore = Math.max(theory.bestScore, score);
    theory.incorrectTopics = [...incorrect];
    save();
    render();
  };

  const renderTest = (module) => {
    const questions = questionsFor(module);
    const card = sectionCard("Теоретическая проверка", `проходной результат ${module.test.passScore} / ${questions.length}`, `test-${module.id}`);
    if (!materialsDone(module)) {
      const remaining = module.sections.length - Object.values(moduleState(module.id).materialsCompleted).filter(Boolean).length;
      append(card, create("div", "locked-message", `Сначала отметьте изучение всех разделов. Осталось: ${remaining}.`));
      return card;
    }
    const form = create("form", "test-form");
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!storageReadonly) evaluateTest(module);
    });
    questions.forEach((question, questionIndex) => {
      const fieldset = create("fieldset", "question-card");
      append(fieldset, create("legend", "", `${String(questionIndex + 1).padStart(2, "0")}. ${question.prompt}`));
      question.options.forEach((option, optionIndex) => {
        const label = create("label", "option-row");
        const input = create("input", "");
        input.type = "radio";
        input.name = question.id;
        input.value = String(optionIndex);
        input.checked = Number(moduleState(module.id).theory.answers[question.id]) === optionIndex;
        input.disabled = storageReadonly;
        input.addEventListener("change", () => {
          moduleState(module.id).theory.answers[question.id] = optionIndex;
          save();
        });
        append(label, input, create("span", "option-dot"), create("span", "", option));
        append(fieldset, label);
      });
      append(form, fieldset);
    });
    const actions = create("div", "test-actions");
    const submit = create("button", "button button-primary", moduleState(module.id).theory.attempts ? "Пройти тест снова" : "Проверить ответы");
    submit.type = "submit";
    submit.disabled = storageReadonly;
    append(actions, submit, create("span", "attempt-count", `Попыток: ${moduleState(module.id).theory.attempts}`));
    append(form, actions);
    append(card, form, renderTestResult(module));
    return card;
  };

  const renderReviewEditor = (review, onSave, title) => {
    const panel = create("div", "mentor-panel");
    append(panel, create("p", "eyebrow", title));
    const select = create("select", "field-control");
    (practiceConfig.reviewStatuses || []).forEach((status) => {
      const option = create("option", "", status.label);
      option.value = status.id;
      option.selected = review.status === status.id;
      append(select, option);
    });
    const textarea = create("textarea", "field-control");
    textarea.placeholder = "Короткий комментарий наставника";
    textarea.value = review.comment;
    select.disabled = storageReadonly;
    textarea.disabled = storageReadonly;
    const saveButton = button("Сохранить решение", "button button-secondary", () => onSave(select.value, textarea.value));
    saveButton.disabled = storageReadonly;
    append(panel, create("label", "field-label", "Статус"), select, create("label", "field-label", "Комментарий"), textarea, saveButton);
    if (review.confirmedAt) append(panel, create("p", "saved-at", `Последнее решение: ${new Date(review.confirmedAt).toLocaleString("ru-RU")}`));
    return panel;
  };

  const renderModuleReview = (module) => {
    const card = sectionCard(module.mentorReviewTitle, reviewLabel(moduleState(module.id).mentorReview.status));
    const grid = create("div", "review-layout");
    const requirements = create("div", "review-requirements");
    const items = module.id === "02"
      ? [
          [materialsDone(module), "Все учебные разделы изучены"],
          [theoryPassed(module), `Тест пройден минимум на ${module.test.passScore}/${questionsFor(module).length}`],
          [allModule02SkillsWithMentor(), "Все пять услуг выполнены минимум с наставником"]
        ]
      : [[materialsDone(module), "Все учебные разделы изучены"], [theoryPassed(module), `Тест пройден минимум на ${module.test.passScore}/${questionsFor(module).length}`]];
    items.forEach(([done, label]) => append(requirements, create("div", done ? "requirement requirement-done" : "requirement", `${done ? "✓" : "○"} ${label}`)));
    const review = moduleState(module.id).mentorReview;
    const editor = renderReviewEditor(review, (status, comment) => {
      review.status = status;
      review.comment = comment;
      review.confirmedAt = todayIso();
      save();
      render();
    }, "Решение наставника");
    append(grid, requirements, editor);
    append(card, grid);
    return card;
  };

  const reviewLabel = (status) => ({ pending: "ожидает проверки", accepted: "принято", repeat: "нужно повторить" }[status] || "ожидает проверки");

  const renderPractice = () => {
    const card = sectionCard("Карта практических навыков", allModule02SkillsWithMentor() ? "этап занятия выполнен" : "пять услуг", "practice-02");
    if (!materialsDone(modules.find((module) => module.id === "02"))) {
      append(card, create("div", "locked-message", "Карта откроется после изучения материалов занятия. Теория и практика учитываются отдельно."));
      return card;
    }
    append(card, create("p", "practice-intro", "Уровни отмечаются строго по порядку. Самостоятельное выполнение может продолжаться после открытия следующего занятия; решение наставника хранится отдельно от уровня."));
    const grid = create("div", "skills-grid");
    (practiceConfig.module02Skills || []).forEach((skill) => {
      const state = progress.skills[skill.id];
      const skillCard = create("article", "skill-card");
      const heading = create("div", "skill-heading");
      const skillTitle = create("div", "");
      append(skillTitle, create("p", "skill-time", skill.timing), create("h3", "", skill.title));
      append(heading, skillTitle, create("span", "skill-level", levelById(state.level).label));
      append(skillCard, heading);
      const levels = create("div", "level-track");
      (practiceConfig.levels || []).forEach((level) => {
        const control = create("button", level.rank <= skillRank(skill.id) ? "level-step level-step-done" : "level-step");
        control.type = "button";
        control.textContent = level.label;
        control.disabled = storageReadonly || level.rank !== skillRank(skill.id) + 1;
        if (!control.disabled) control.addEventListener("click", () => {
          state.level = level.id;
          save();
          render();
          document.getElementById("practice-02")?.scrollIntoView({ block: "start" });
        });
        append(levels, control);
      });
      append(skillCard, levels);
      const details = create("details", "skill-criteria");
      append(details, create("summary", "", "Критерии наблюдения"));
      const list = create("ul", "content-list compact-list");
      skill.criteria.forEach((criterion) => append(list, create("li", "", criterion)));
      append(details, list, sourceLine(skill.sourceIds));
      append(skillCard, details);
      const review = renderReviewEditor(state.mentorReview, (status, comment) => {
        state.mentorReview.status = status;
        state.mentorReview.comment = comment;
        state.mentorReview.confirmedAt = todayIso();
        save();
        render();
      }, "Проверка навыка");
      append(skillCard, review);
      append(grid, skillCard);
    });
    append(card, grid);
    const checklist = create("details", "mentor-checklist");
    append(checklist, create("summary", "", "Общий практический чек-лист наставника"));
    const list = create("ol", "content-list");
    (practiceConfig.module02MentorChecklist || []).forEach((item) => append(list, create("li", "", item)));
    append(checklist, list);
    append(card, checklist);
    return card;
  };

  const renderManualUnlock = (module) => {
    const currentIndex = modules.findIndex((item) => item.id === module.id);
    const next = modules[currentIndex + 1];
    if (!next || moduleUnlocked(next)) return null;
    const card = sectionCard("Изменение порядка практики", `следующее занятие · ${next.id}`);
    append(card, create("p", "lesson-copy", `Основной маршрут последовательный. Наставник может отдельно открыть «${next.title}», если порядок ознакомления с услугами нужно изменить.`));
    const textarea = create("textarea", "field-control unlock-comment");
    textarea.placeholder = "Комментарий наставника — необязательно";
    textarea.disabled = storageReadonly;
    const unlock = button(`Открыть занятие ${next.id}`, "button button-outline-amber", () => {
      const confirmed = window.confirm(`Открыть занятие «${next.title}» раньше? Предыдущее занятие и навыки не будут зачтены автоматически.`);
      if (!confirmed) return;
      progress.manualUnlocks[next.id] = { openedAt: todayIso(), comment: textarea.value.trim() };
      progress.currentModuleId = next.id;
      save();
      render();
    });
    unlock.disabled = storageReadonly;
    append(card, textarea, unlock, create("p", "manual-warning", "Ручное открытие не завершает текущее занятие и не меняет тесты, уровни навыков или решения наставника."));
    return card;
  };

  const renderModuleStatus = (module) => {
    const card = sectionCard("Статус занятия", moduleComplete(module) ? "завершено" : "в процессе");
    const grid = create("div", "status-grid");
    const items = [
      ["Материал", materialsDone(module) ? "изучен" : "не завершён", materialsDone(module)],
      ["Теория", theoryPassed(module) ? `лучший результат ${moduleState(module.id).theory.bestScore}/${questionsFor(module).length}` : "не пройдена", theoryPassed(module)],
      [module.id === "02" ? "Практика занятия" : "Наставник", module.id === "02" ? (allModule02SkillsWithMentor() ? "5/5 с наставником" : "продолжается") : reviewLabel(moduleState(module.id).mentorReview.status), module.id === "02" ? allModule02SkillsWithMentor() : reviewAccepted(module)],
      ["Подтверждение", reviewLabel(moduleState(module.id).mentorReview.status), reviewAccepted(module)]
    ];
    items.forEach(([label, value, done]) => {
      const item = create("div", done ? "status-card status-card-done" : "status-card");
      append(item, create("span", "status-card-label", label), create("strong", "", value));
      append(grid, item);
    });
    append(card, grid);
    return card;
  };

  const renderFullModule = (module) => {
    const content = create("main", "module-content");
    append(content, renderLead(module), renderOutcomes(module), renderSectionNav(module), renderLearningSections(module), renderTest(module));
    if (module.id === "02") append(content, renderPractice());
    append(content, renderModuleReview(module), renderModuleStatus(module), renderManualUnlock(module));
    return content;
  };

  const renderUnfinished = (module) => {
    const content = create("main", "module-content");
    append(content, renderLead(module));
    const card = sectionCard("Структура зафиксирована", "наполнение не завершено");
    append(card, create("p", "lesson-copy", module.summary), create("aside", "editorial-note", module.missing));
    if (progress.manualUnlocks[module.id]) {
      const unlock = progress.manualUnlocks[module.id];
      append(card, create("p", "mentor-opened-note", `Открыто наставником: ${new Date(unlock.openedAt).toLocaleString("ru-RU")}${unlock.comment ? ` · ${unlock.comment}` : ""}. Это не является зачётом предыдущего занятия.`));
    }
    append(card, sourceLine(module.sourceIds));
    append(content, card, renderManualUnlock(module));
    return content;
  };

  const renderMain = () => {
    const selected = modules.find((module) => module.id === progress.currentModuleId) || modules[0];
    return selected.kind === "full" ? renderFullModule(selected) : renderUnfinished(selected);
  };

  function resetProgress() {
    const message = storageReadonly
      ? "Удалить несовместимый сохранённый прогресс и начать v0.2 заново?"
      : "Сбросить весь прогресс v0.2 на этом устройстве? Действие нельзя отменить.";
    if (!window.confirm(message)) return;
    localStorage.removeItem(STORAGE_KEY);
    storageReadonly = false;
    systemNotice = "";
    progress = defaultProgress();
    render();
  }

  function render() {
    app.replaceChildren();
    const frame = create("div", "page-frame");
    append(frame, renderHeader());
    renderNotices(frame);
    append(frame, renderSummary());
    const workspace = create("div", "workspace");
    append(workspace, renderRoute(), renderMain());
    append(frame, workspace, create("footer", "page-footer", "TOPGUN · Старт v0.2 · практика подтверждается наставником · данные хранятся только на этом устройстве."));
    append(app, frame);
  }

  const contentValid = modules.length === 6
    && fullModules().length === 2
    && questionsFor(modules[0]).length === 8
    && questionsFor(modules[1]).length === 10
    && (practiceConfig.module02Skills || []).length === 5
    && sourceConfig.policy?.firstRule;
  if (!contentValid) {
    app.replaceChildren(create("p", "fatal-error", "Не удалось загрузить структуру v0.2. Проверьте файлы в папке content."));
    return;
  }
  render();
})();
