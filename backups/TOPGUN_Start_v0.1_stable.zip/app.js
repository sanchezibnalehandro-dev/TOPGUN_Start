(() => {
  "use strict";

  const STORAGE_KEY = "topgun-start-progress";
  const SCHEMA_VERSION = 1;
  const modules = Array.isArray(window.TOPGUN_MODULES) ? window.TOPGUN_MODULES : [];
  const questions = Array.isArray(window.TOPGUN_QUESTIONS) ? window.TOPGUN_QUESTIONS : [];
  const module02 = modules.find((module) => module.id === "02");
  const app = document.getElementById("app");
  let storageReadonly = false;
  let futureSchemaNotice = "";

  const create = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };

  const append = (parent, ...children) => {
    children.flat().filter(Boolean).forEach((child) => parent.append(child));
    return parent;
  };

  const button = (label, className, onClick) => {
    const node = create("button", className, label);
    node.type = "button";
    node.addEventListener("click", onClick);
    return node;
  };

  const sectionCard = (title, meta) => {
    const card = create("section", "surface reveal");
    const header = create("div", "section-heading");
    append(header, create("h2", "section-title", title));
    if (meta) append(header, create("span", "section-meta", meta));
    append(card, header);
    return card;
  };

  const defaultProgress = () => ({
    progressSchemaVersion: SCHEMA_VERSION,
    traineeName: "Стажёр",
    currentModuleId: "02",
    modules: {
      "02": {
        checklist: Array(module02?.checklist?.length || 5).fill(false),
        answers: {},
        attempts: 0,
        bestScore: 0,
        lastScore: null,
        lastIncorrectTopics: [],
        practice: { status: "pending", comment: "" }
      }
    }
  });

  const normalize = (candidate) => {
    const base = defaultProgress();
    if (!candidate || typeof candidate !== "object") return base;
    const oldModule = candidate.modules?.["02"] || candidate.module02 || {};
    const wantedChecks = base.modules["02"].checklist.length;
    const oldChecks = Array.isArray(oldModule.checklist) ? oldModule.checklist : candidate.checks;
    const checklist = Array.from({ length: wantedChecks }, (_, index) => Boolean(oldChecks?.[index]));
    const status = ["pending", "accepted", "repeat"].includes(oldModule.practice?.status)
      ? oldModule.practice.status
      : ["pending", "accepted", "repeat"].includes(oldModule.mentor)
        ? oldModule.mentor
        : "pending";
    const practiceComment = typeof oldModule.practice?.comment === "string"
      ? oldModule.practice.comment
      : typeof oldModule.comment === "string" ? oldModule.comment : "";

    return {
      progressSchemaVersion: SCHEMA_VERSION,
      traineeName: typeof candidate.traineeName === "string" && candidate.traineeName.trim()
        ? candidate.traineeName.trim()
        : typeof candidate.name === "string" && candidate.name.trim() ? candidate.name.trim() : base.traineeName,
      currentModuleId: modules.some((module) => module.id === candidate.currentModuleId || module.id === candidate.current)
        ? (candidate.currentModuleId || candidate.current)
        : base.currentModuleId,
      modules: {
        "02": {
          checklist,
          answers: oldModule.answers && typeof oldModule.answers === "object" ? oldModule.answers : {},
          attempts: Number.isInteger(oldModule.attempts) ? Math.max(0, oldModule.attempts) : 0,
          bestScore: Number.isInteger(oldModule.bestScore) ? Math.max(0, oldModule.bestScore) : Math.max(0, oldModule.score || candidate.score || 0),
          lastScore: Number.isInteger(oldModule.lastScore) ? oldModule.lastScore : null,
          lastIncorrectTopics: Array.isArray(oldModule.lastIncorrectTopics) ? oldModule.lastIncorrectTopics.filter((item) => typeof item === "string") : [],
          practice: { status, comment: practiceComment }
        }
      }
    };
  };

  const loadProgress = () => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return defaultProgress();
      const parsed = JSON.parse(raw);
      if (Number(parsed.progressSchemaVersion) > SCHEMA_VERSION) {
        storageReadonly = true;
        futureSchemaNotice = "Этот прогресс создан более новой версией приложения. Он не будет изменён; для начала новой демонстрации используйте сброс.";
        return defaultProgress();
      }
      const migrated = normalize(parsed);
      if (Number(parsed.progressSchemaVersion) !== SCHEMA_VERSION) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(migrated));
      }
      return migrated;
    } catch {
      futureSchemaNotice = "Не удалось прочитать локальный прогресс. Открыта чистая демонстрация; сохранённые данные не изменены.";
      storageReadonly = true;
      return defaultProgress();
    }
  };

  let progress = loadProgress();
  const state02 = () => progress.modules["02"];
  const checklistDone = () => state02().checklist.every(Boolean);
  const testPassed = () => state02().bestScore >= 6;
  const moduleComplete = () => checklistDone() && testPassed() && state02().practice.status === "accepted";
  const progressPercent = () => {
    const steps = [checklistDone(), testPassed(), state02().practice.status === "accepted"];
    return Math.round((steps.filter(Boolean).length / steps.length) * 100);
  };

  const save = () => {
    if (storageReadonly) return false;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    return true;
  };

  const statusLabel = (status) => ({ pending: "ожидает проверки", accepted: "принято", repeat: "нужно повторить" }[status]);
  const moduleStatus = (module) => {
    if (module.id === "01") return { tone: "demo", label: "демо-структура", locked: false };
    if (module.id === "02") return moduleComplete()
      ? { tone: "done", label: "завершён", locked: false }
      : { tone: "current", label: "сейчас", locked: false };
    return moduleComplete()
      ? { tone: "demo", label: "демо-структура", locked: false }
      : { tone: "locked", label: "закрыт", locked: true };
  };

  const renderHeader = () => {
    const header = create("header", "topbar");
    const brand = create("div", "brand-block");
    append(brand, create("p", "eyebrow", "TOPGUN · внутренняя стажировка"), create("h1", "brand-title", "Старт"), create("p", "brand-copy", "Демонстрационный маршрут нового барбера"));
    const actions = create("div", "top-actions");
    append(actions,
      button("Изменить имя", "button button-quiet", () => {
        const value = window.prompt("Имя стажёра:", progress.traineeName);
        if (value && value.trim()) {
          progress.traineeName = value.trim();
          save();
          render();
        }
      }),
      button("Сбросить демо-прогресс", "button button-outline", resetProgress)
    );
    append(header, brand, actions);
    return header;
  };

  const renderSummary = () => {
    const summary = create("section", "journey-hero");
    const copy = create("div", "hero-copy");
    const marker = create("span", "demo-marker", "DEMO · синтетический контент");
    append(copy, marker, create("p", "hero-kicker", "Ваш маршрут"), create("h2", "hero-title", moduleComplete() ? "Модуль «Клиент и сервис» завершён" : "Следующий шаг — модуль 02"));
    const message = moduleComplete()
      ? "Демо-модуль пройден. Следующие этапы показаны как структура будущего маршрута."
      : checklistDone() && !testPassed()
        ? "Чек-лист завершён. Проверьте знания в мини-тесте."
        : testPassed()
          ? "Теория пройдена. Практику подтверждает наставник."
          : "Пройдите материал и завершите чек-лист, чтобы открыть тест.";
    append(copy, create("p", "hero-text", message));
    const dial = create("div", "progress-dial");
    dial.style.setProperty("--progress", `${progressPercent() * 3.6}deg`);
    append(dial, create("strong", "progress-value", `${progressPercent()}%`), create("span", "progress-caption", "модуль 02"));
    append(summary, copy, dial);
    return summary;
  };

  const renderRoute = () => {
    const aside = create("aside", "route-panel");
    append(aside, create("p", "eyebrow", "Маршрут стажировки"), create("h2", "route-title", "Шесть этапов"), create("p", "route-caption", "Один полный демо-модуль · остальные этапы — структура."));
    const list = create("nav", "route-list");
    list.setAttribute("aria-label", "Маршрут стажировки");
    modules.forEach((module) => {
      const status = moduleStatus(module);
      const item = create("button", `route-item route-${status.tone}`);
      item.type = "button";
      item.disabled = status.locked || storageReadonly;
      item.setAttribute("aria-current", progress.currentModuleId === module.id ? "step" : "false");
      const number = create("span", "route-number", module.id);
      const content = create("span", "route-content");
      append(content, create("span", "route-name", module.title), create("span", "route-summary", module.summary));
      append(item, number, content, create("span", `route-status status-${status.tone}`, status.label));
      if (!status.locked) item.addEventListener("click", () => {
        progress.currentModuleId = module.id;
        save();
        render();
      });
      append(list, item);
    });
    append(aside, list);
    return aside;
  };

  const renderModuleLead = () => {
    const lead = create("section", "module-lead reveal");
    append(lead, create("p", "eyebrow", "02 · демонстрационный модуль"), create("h1", "module-title", module02.title), create("p", "module-purpose", module02.purpose));
    const stages = create("ol", "stage-list");
    const states = [true, true, checklistDone(), testPassed(), state02().practice.status === "accepted"];
    ["Зачем", "Материал", "Чек-лист", "Тест", "Практика"].forEach((name, index) => {
      const stage = create("li", states[index] ? "stage-complete" : index === (states.findIndex((state) => !state)) ? "stage-current" : "stage-pending", name);
      append(stages, stage);
    });
    append(lead, stages);
    return lead;
  };

  const renderDemoNote = () => {
    const note = create("aside", "demo-note", "ДЕМО-КОНТЕНТ. Формулировки ниже не являются официальными стандартами TOPGUN.");
    note.setAttribute("role", "note");
    return note;
  };

  const renderLearning = () => {
    const card = sectionCard("После модуля стажёр должен уметь", "наблюдаемые действия");
    const grid = create("div", "outcomes-grid");
    module02.outcomes.forEach((outcome, index) => {
      const item = create("div", "outcome-item");
      append(item, create("span", "outcome-index", String(index + 1).padStart(2, "0")), create("p", "", outcome));
      append(grid, item);
    });
    append(card, grid, renderDemoNote());
    return card;
  };

  const renderLesson = () => {
    const card = sectionCard(module02.lessonTitle, "демо-памятка");
    const steps = create("ol", "lesson-steps");
    module02.lesson.forEach((item, index) => {
      const step = create("li", "lesson-step");
      append(step, create("span", "lesson-index", String(index + 1).padStart(2, "0")), create("div", "", [create("h3", "", item.title), create("p", "", item.text)]));
      append(steps, step);
    });
    append(card, steps);
    return card;
  };

  const renderChecklist = () => {
    const doneCount = state02().checklist.filter(Boolean).length;
    const card = sectionCard("Чек-лист перед тестом", `${doneCount} / ${module02.checklist.length}`);
    const list = create("div", "checklist");
    module02.checklist.forEach((text, index) => {
      const label = create("label", "check-row");
      const input = create("input", "");
      input.type = "checkbox";
      input.checked = Boolean(state02().checklist[index]);
      input.disabled = storageReadonly;
      input.addEventListener("change", () => {
        state02().checklist[index] = input.checked;
        save();
        render();
      });
      append(label, input, create("span", "check-box"), create("span", "check-copy", text));
      append(list, label);
    });
    append(card, list);
    return card;
  };

  const renderResult = () => {
    const result = state02();
    if (result.lastScore === null) return null;
    const passed = result.lastScore >= 6;
    const panel = create("div", `test-result ${passed ? "result-good" : "result-bad"}`);
    append(panel, create("strong", "", passed ? `Тест пройден · ${result.lastScore}/8` : `${result.lastScore}/8 · стоит повторить материал`));
    if (passed) {
      append(panel, create("p", "", "Теоретическая часть завершена. Следующий этап — практика с наставником."));
    } else {
      const topics = result.lastIncorrectTopics.length ? result.lastIncorrectTopics.join(", ") : "все вопросы";
      append(panel, create("p", "", `Повторите темы: ${topics}. Попыток: ${result.attempts}.`));
    }
    return panel;
  };

  const evaluateTest = () => {
    const result = state02();
    let score = 0;
    const incorrectTopics = new Set();
    questions.forEach((question) => {
      if (Number(result.answers[question.id]) === question.correctIndex) score += 1;
      else incorrectTopics.add(question.topic);
    });
    result.attempts += 1;
    result.lastScore = score;
    result.bestScore = Math.max(result.bestScore, score);
    result.lastIncorrectTopics = [...incorrectTopics];
    save();
    render();
  };

  const renderTest = () => {
    const card = sectionCard("Мини-тест", "проходной результат 6 / 8");
    if (!checklistDone()) {
      const lock = create("div", "locked-message");
      append(lock, create("strong", "", "Тест пока закрыт"), create("p", "", `Завершите чек-лист: осталось ${module02.checklist.length - state02().checklist.filter(Boolean).length} пункт(а).`));
      append(card, lock);
      return card;
    }
    append(card, create("p", "test-intro", "Выберите один ответ для каждого вопроса, затем проверьте результат."));
    const form = create("form", "test-form");
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!storageReadonly) evaluateTest();
    });
    questions.forEach((question, questionIndex) => {
      const fieldset = create("fieldset", "question-card");
      append(fieldset, create("legend", "", `${String(questionIndex + 1).padStart(2, "0")}. ${question.prompt}`));
      question.options.forEach((option, optionIndex) => {
        const label = create("label", "option-row");
        const input = create("input", "");
        input.type = "radio";
        input.name = question.id;
        input.value = String(optionIndex);
        input.checked = Number(state02().answers[question.id]) === optionIndex;
        input.disabled = storageReadonly;
        input.addEventListener("change", () => {
          state02().answers[question.id] = optionIndex;
          save();
        });
        append(label, input, create("span", "option-dot"), create("span", "", option));
        append(fieldset, label);
      });
      append(form, fieldset);
    });
    const actions = create("div", "test-actions");
    const submit = create("button", "button button-primary", state02().attempts ? "Пройти тест снова" : "Проверить тест");
    submit.type = "submit";
    submit.disabled = storageReadonly;
    append(actions, submit, create("span", "attempt-count", `Попыток: ${state02().attempts}`));
    append(form, actions);
    append(card, form, renderResult());
    return card;
  };

  const renderPractice = () => {
    const card = sectionCard("Практика с наставником", testPassed() ? statusLabel(state02().practice.status) : "после теста");
    if (!testPassed()) {
      const lock = create("div", "locked-message");
      append(lock, create("strong", "", "Практика станет доступна после теста"), create("p", "", "Наставник сможет подтвердить или вернуть практическое задание после успешной теории."));
      append(card, lock);
      return card;
    }
    const layout = create("div", "practice-layout");
    const task = create("div", "practice-task");
    append(task, create("h3", "", module02.practice.title), create("p", "", module02.practice.instruction));
    const criteria = create("ul", "practice-criteria");
    module02.practice.criteria.forEach((criterion) => append(criteria, create("li", "", criterion)));
    append(task, criteria, renderDemoNote());
    const mentor = create("div", "mentor-panel");
    append(mentor, create("p", "eyebrow", "Решение наставника"));
    const selectLabel = create("label", "field-label", "Статус практики");
    const select = create("select", "field-control");
    [
      ["pending", "Ожидает проверки"],
      ["accepted", "Принято"],
      ["repeat", "Нужно повторить"]
    ].forEach(([value, label]) => {
      const option = create("option", "", label);
      option.value = value;
      option.selected = state02().practice.status === value;
      append(select, option);
    });
    select.disabled = storageReadonly;
    const commentLabel = create("label", "field-label", "Короткий комментарий");
    const textarea = create("textarea", "field-control");
    textarea.value = state02().practice.comment;
    textarea.placeholder = "Например: повторить уточняющие вопросы.";
    textarea.disabled = storageReadonly;
    const saveButton = button("Сохранить решение", "button button-secondary", () => {
      state02().practice.status = select.value;
      state02().practice.comment = textarea.value;
      save();
      render();
    });
    saveButton.disabled = storageReadonly;
    append(mentor, selectLabel, select, commentLabel, textarea, saveButton);
    append(layout, task, mentor);
    append(card, layout);
    return card;
  };

  const renderModuleStatus = () => {
    const card = sectionCard("Статус модуля", moduleComplete() ? "завершён" : "в процессе");
    const grid = create("div", "status-grid");
    const states = [
      ["Чек-лист", checklistDone() ? "5/5 завершено" : `${state02().checklist.filter(Boolean)}/5 в работе`, checklistDone() ? "done" : "current"],
      ["Тест", testPassed() ? `лучший результат ${state02().bestScore}/8` : "ещё не пройден", testPassed() ? "done" : "current"],
      ["Практика", statusLabel(state02().practice.status), state02().practice.status === "accepted" ? "done" : state02().practice.status === "repeat" ? "repeat" : "current"]
    ];
    states.forEach(([label, value, tone]) => {
      const item = create("div", `status-card status-card-${tone}`);
      append(item, create("span", "status-card-label", label), create("strong", "", value));
      append(grid, item);
    });
    append(card, grid);
    return card;
  };

  const renderStub = (module) => {
    const status = moduleStatus(module);
    const content = create("main", "module-content");
    const stub = create("section", "stub-view reveal");
    append(stub, create("p", "eyebrow", `${module.id} · ${status.locked ? "пока закрыто" : "демо-структура"}`), create("h1", "module-title", module.title));
    append(stub, create("p", "module-purpose", status.locked ? "Этот этап откроется после завершения модуля «Клиент и сервис»." : "Структура видна заранее, но учебное содержание ещё не добавлено."));
    append(stub, renderDemoNote());
    append(content, stub);
    return content;
  };

  const renderMain = () => {
    const selected = modules.find((module) => module.id === progress.currentModuleId) || module02;
    if (selected.id !== "02") return renderStub(selected);
    const content = create("main", "module-content");
    append(content, renderModuleLead(), renderLearning(), renderLesson(), renderChecklist(), renderTest(), renderPractice(), renderModuleStatus());
    return content;
  };

  const resetProgress = () => {
    const text = storageReadonly
      ? "Удалить несовместимый сохранённый прогресс и начать новую демонстрацию?"
      : "Сбросить весь демо-прогресс на этом устройстве? Это действие нельзя отменить.";
    if (!window.confirm(text)) return;
    localStorage.removeItem(STORAGE_KEY);
    storageReadonly = false;
    futureSchemaNotice = "";
    progress = defaultProgress();
    render();
  };

  const render = () => {
    app.replaceChildren();
    const frame = create("div", "page-frame");
    append(frame, renderHeader());
    if (futureSchemaNotice) append(frame, create("div", "schema-notice", futureSchemaNotice));
    append(frame, renderSummary());
    const workspace = create("div", "workspace");
    append(workspace, renderRoute(), renderMain());
    append(frame, workspace, create("footer", "page-footer", "TOPGUN · Старт v0.1 · весь учебный контент демонстрационный."));
    append(app, frame);
  };

  if (!module02 || questions.length !== 8) {
    app.replaceChildren(create("p", "fatal-error", "Не удалось загрузить демонстрационный контент. Проверьте папку content."));
    return;
  }
  render();
})();
